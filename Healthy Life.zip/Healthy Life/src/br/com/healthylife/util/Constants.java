/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.healthylife.util;

/**
 *
 * @author aluno
 */
public class Constants {

    public static final String LOGIN_INVALID = "Login ou Senha incorretos!";
    public static final String FRAME_TITLE = "Healthy Life";
    public static final String ABOUT_MESSAGE = "Healthy Life \nVersion 0.1"
            + " \nby Ruann Karllos / Carlos Henrique / Kleyvson Matias \nS.A.C. \n0800 - 2361";
    public static final String REGISTRATION_EMPLOYEE_TITLE = "Cadastro de Funcionário";
    public static final String REGISTRATION_MEDIC_TITLE = "Cadastro de Médicos";
    public static final String REGISTRATION_CLIENT_TITLE = "Cadastro de Clientes";
    public static final String REGISTRATION_HOSPITAL_TITLE = "Cadastro de Hospital";
}
